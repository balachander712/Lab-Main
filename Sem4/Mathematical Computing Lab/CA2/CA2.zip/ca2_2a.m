syms x y z
int(int(int((2*x),z,[0 6-2*x-3*y]),y,[0 -(2/3)*x+2]),x,[0 3])