syms x y z
int(int(int(1,x,[0 8-y-z]),z,[(3/4)*y (3/2)*sqrt(y)]),y,[0 4])