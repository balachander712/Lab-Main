num = input('Please enter the number: ');
func(num)
