R = input('Enter the marks of students\n');
g = fgrade(R);
fprintf('The grades are\n');
g