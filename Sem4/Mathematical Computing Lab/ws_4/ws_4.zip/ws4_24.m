for i = 1:1000;
    if isprime(i)
        fprintf('%d\n', i)
    end
end