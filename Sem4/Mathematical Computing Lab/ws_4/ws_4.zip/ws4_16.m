sum = 0;
for i = 1:2:501
    sum = sum + (i);
end
fprintf('The sum of odd integers from 1 to 501 is %d\n', sum)