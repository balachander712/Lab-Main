sum = 0;
for i = 2:20
    sum = sum + (i*i);
end
fprintf('The sum of squares from 2 to 20 is %d\n', sum)