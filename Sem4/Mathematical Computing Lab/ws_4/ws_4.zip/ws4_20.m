fprintf('Area of triangle with sides 3, 8 and 10 is %f \n', triangle(3, 8, 10));
fprintf('Area of triangle with sides 7, 7 and 5 is %f \n', triangle(7, 7, 5));