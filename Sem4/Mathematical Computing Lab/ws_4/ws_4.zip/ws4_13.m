num = input('Please enter the number: ');
fprintf('The factorial of the number is %d\n', getFac(num))
