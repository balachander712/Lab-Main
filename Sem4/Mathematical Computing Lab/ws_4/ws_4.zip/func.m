

function [  ] = func( num )
    printFib([0 1], num)
end
