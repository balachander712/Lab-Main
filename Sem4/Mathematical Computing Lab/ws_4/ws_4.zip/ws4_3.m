ws4_3_function([-2.5])
ws4_3_function([3])

x = linspace(-3, 4);
plot(x, ws4_3_function(x))