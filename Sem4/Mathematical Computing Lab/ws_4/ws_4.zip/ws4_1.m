eval(6)
eval([1 3 5 7 9 11])