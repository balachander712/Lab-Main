num = input('Please enter the number: ');

if num == 0
    display('Number is 0')
elseif num > 0  
    display('Number is positive')
else
    display('Number is negative')
end