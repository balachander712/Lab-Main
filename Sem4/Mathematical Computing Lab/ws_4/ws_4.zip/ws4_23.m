x = input('Please enter the number: ');
for i = 0:2:x
    fprintf('square root of %d is %f\n',i, i^0.5);
end