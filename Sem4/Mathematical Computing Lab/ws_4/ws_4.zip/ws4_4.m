x = input('Please enter the co-efficients of the polynomial: ', 's');
numbers = sscanf(x, '%f');
roots(numbers)