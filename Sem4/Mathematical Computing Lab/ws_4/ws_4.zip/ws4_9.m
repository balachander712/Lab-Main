num = input('Please enter the number: ');
if isprime(num) == 1
    display('The given number is Prime')
else 
    display('The given number is not Prime')
end