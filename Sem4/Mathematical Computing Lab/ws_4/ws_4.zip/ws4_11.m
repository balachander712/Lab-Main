for i = 1:4
    for j = 1:i
        fprintf('*')
    end
    fprintf('\n')
end