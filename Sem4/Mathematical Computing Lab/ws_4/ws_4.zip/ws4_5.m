num = input('Please enter the number: ');

if bitand(num, 1) == 0
    display('Number is even')
else 
    display('Number is odd')
end