function [ mps ] = mphToMps( mph )
    mps = mph*0.44704;
end

