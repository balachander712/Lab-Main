temp = input('Please enter the temparature: ');

if temp < 32
    display('ICE')
elseif temp < 212  
    display('WATER')
else
    display('STEAM')
end