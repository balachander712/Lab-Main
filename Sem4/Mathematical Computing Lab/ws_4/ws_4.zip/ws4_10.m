for i = 1:20
    fprintf('13 x %d = %d\n', i, i*13)
end