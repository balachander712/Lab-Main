for i = 1:5
    for j = 1:i/2
        fprintf(' ')
    end
    for j = 1:i
        fprintf('*')
    end
    fprintf('\n')
end