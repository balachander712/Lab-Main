average([80 75 91 60 79 89 65 80 95 50 81])
standard_deviation([80 75 91 60 79 89 65 80 95 50 81])