<?php

    phpinfo();


?>