<?php
    for($x=1; $x<=10; $x++)
    {
        if($x< 10)
        {
            echo "$x-";
        }
        else
        {
            echo "$x"."\n";
        }
    }
?>