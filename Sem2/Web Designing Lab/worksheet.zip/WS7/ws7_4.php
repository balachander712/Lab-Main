<?php
    echo  date("h:i:sa");
?>