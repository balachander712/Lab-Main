<?php
    $str = "The quick brown fox";
    echo $str . "<br>";
    $new_str = str_replace(' ', '', $str);
    echo $new_str;
?>